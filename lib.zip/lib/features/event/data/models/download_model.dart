import 'package:cpn_us/features/event/domain/entities/download.dart';

class DownloadModel extends Download{
  DownloadModel({ 
    super.downloadFileName,
    super.downloadPercentage,  
    super.downloadStatus});

}