
// import 'dart:html';

// import 'package:flutter/material.dart';
// import 'package:flutter/src/widgets/framework.dart';

// import 'package:html/parser.dart' show parse;



// class HtmlParssers extends StatelessWidget {
//   final String data;
//   const HtmlParssers({super.key,required this.data});

//   @override
//   Widget build(BuildContext context) {
//     return 
//       Document(parse(data));
//   }
// }
